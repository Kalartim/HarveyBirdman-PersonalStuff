﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fish_Movement : MonoBehaviour
{

    public Rigidbody2D fishRB;
    public Transform front;
    public GameObject fishTail;
    public GameObject tailTurnPoint;
    Vector2 fish;
    Vector2 movePoint;
    Vector3 relativePos;
    public float speed = 4f;
    float turnSpeed = 15f;
    public float time = 0;
    public float timeThreshold;
    public float hungerTime = 0;
    public float hungerTimeThreshold;
    public float energy;
    public CounterScript counter;
   

    // Start is called before the first frame update
    void Start()
    {
        counter = GameObject.Find("GameManager").GetComponent<CounterScript>();
        energy = speed / 2; ;
        relativePos = tailTurnPoint.transform.position;

    }

    // Update is called once per frame
    void Update()
    {

        Timer();
        HungerTimer();
        SpeedDecay();
        FishRotation();
        FishMotion();
        Vector3 pos = transform.position;
        pos.z = -1;


    }

    public void FishRotation()
    {
        

        if (Input.GetButtonDown("Left Bumper") || Input.GetKeyDown(KeyCode.A))
        {
            speed++;
            transform.Rotate(new Vector3(0, 0, -10) * (speed + energy) * Time.deltaTime);
            tailTurnPoint.transform.Rotate(0, 0, -17);

        }

        if (Input.GetButtonDown("Right Bumper") || Input.GetKeyDown(KeyCode.D))
        {
            speed++; 
            transform.Rotate(new Vector3(0, 0, 10) * (speed + energy) * Time.deltaTime);
            tailTurnPoint.transform.Rotate(0, 0, 17);

        } 
        

        
       else if (Input.GetButton("Left Bumper") || Input.GetKey(KeyCode.A))
       {
           transform.Rotate(new Vector3(0, 0, 5) * turnSpeed * Time.deltaTime);
            if (tailTurnPoint.transform.rotation.z < -17)
            {
                tailTurnPoint.transform.Rotate(0, 0, -17);
            }
       }



        else if (Input.GetButton("Right Bumper") || Input.GetKey(KeyCode.D))
        {
            transform.Rotate(new Vector3(0, 0, -5) * turnSpeed * Time.deltaTime);
            if (tailTurnPoint.transform.rotation.z > 17)
            {
                tailTurnPoint.transform.Rotate(0, 0, 17);
            }
        }


        else
        {
            tailTurnPoint.transform.localRotation = Quaternion.Euler(0, 0, 0);
        }


    }


    public void FishMotion()
    {  
        transform.position = Vector2.MoveTowards(new Vector2(transform.position.x, transform.position.y), new Vector2(front.position.x, front.position.y), speed * Time.deltaTime);
    }

    public void SpeedDecay()
    {
        if (speed >= 10)
        {
            speed = 10;

            if(energy >= 3)
            {
                speed = 15;

                if (energy >= 5)
                {
                    speed = 20;
                }
            }
        }

        if (speed <= 0)
        {
            speed++;
        }

        if (counter.hungerCount < 0)
        {
            counter.hungerCount = 0;
        }

        if (counter.hungerCount > 2)
        {
            speed--;
        }

    }

    public void Timer()
    {
        time += Time.deltaTime;
        if (time >= timeThreshold)
        {
            time = 0;
        }
        if (time == 0 && speed > 0)
        {
            speed--;

        }
        if (time == 0 && energy > 0)
        {
            energy--;
        }
    }

    public void HungerTimer()
    {
        hungerTime += Time.deltaTime;
        if (counter.hungerCount < 0)
        {
            counter.hungerCount++;
        }
    }

}