﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera_Manager : MonoBehaviour
{

    public GameObject fish;

    Vector3 offset;
    // Start is called before the first frame update
    void Start()
    {
        offset = transform.position - fish.transform.position;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        transform.position = fish.transform.position + offset;
    }
}
