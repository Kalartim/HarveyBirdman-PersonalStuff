﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreScript : MonoBehaviour
{
    public AudioSource cronch;
    public Fish_Movement fishy;
    public ParticleSystem feedBack;
    public CounterScript counter;
    public Collider2D fish;
    public int foodScore;
    // Start is called before the first frame update
    void Start()
    {
        fishy = GameObject.Find("FishBody").GetComponent<Fish_Movement>();
        cronch = GameObject.Find("Crunch").GetComponent<AudioSource>();
        counter = GameObject.Find("GameManager").GetComponent<CounterScript>();
        fish = GameObject.Find("FishBody").GetComponent<CapsuleCollider2D>();
    }

    // Update is called once per frame
    void Update()
    {
               
    }

    public void OnTriggerEnter2D(Collider2D fish)
    {
    
        counter.foodCount++;
        fishy.energy++;
        if(fishy.energy > 5)
        {
            fishy.energy = 5;
        }
        foodScore++;
        Destroy(this.gameObject);
        cronch.Play();
        Instantiate(feedBack, transform.position, Quaternion.identity);
       
    }
}
