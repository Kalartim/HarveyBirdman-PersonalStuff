﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scrolling_Background : MonoBehaviour
{

    //Rigidbody2D rb;
    //public GameObject background;
    //float sSpeed = -1.5f;
    // Start is called before the first frame update
    void Start()
    {
       // rb = GetComponent<Rigidbody2D>();
        //rb.velocity = new Vector3(sSpeed, sSpeed, 5);
    }

    // Update is called once per frame
    void Update()
    {
       
    }

    
}
