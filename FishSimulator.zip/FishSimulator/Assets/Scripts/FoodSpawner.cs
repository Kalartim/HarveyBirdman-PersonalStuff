﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FoodSpawner : MonoBehaviour
{
    public GameObject[] fishFood;
    Vector3 spawningPos;
    // Start is called before the first frame update
    void Start()
    {
        spawningPos = new Vector3(Random.Range(-60, 60), Random.Range(-45, 45), 0);
    }

    // Update is called once per frame
    void Update()
    {
        spawningPos = new Vector3(Random.Range(-80, 80), Random.Range(-65, 65), 0);
        InvokeRepeating("FoodSpawn", 1, 50);
    }

    void FoodSpawn()
    {
        Instantiate(fishFood[Random.Range(0, fishFood.Length)], spawningPos, Quaternion.identity);
    }
}
