﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WrapScreenScript : MonoBehaviour
{

    public GameObject fish;
    public GameObject tPoint;
    Collider2D col;
    // Start is called before the first frame update
    void Start()
    {
        col = fish.GetComponent<CapsuleCollider2D>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

     void OnTriggerEnter2D(Collider2D col)
    {
        StartCoroutine(Teleport());
    }

    IEnumerator Teleport()
    {
        TrailRenderer tr = FindObjectOfType<TrailRenderer>();
        tr.emitting = false;
        yield return new WaitForEndOfFrame();
        fish.transform.position = tPoint.transform.position;
        yield return new WaitForEndOfFrame();
        tr.emitting = true;
        yield return null;

    }
}
