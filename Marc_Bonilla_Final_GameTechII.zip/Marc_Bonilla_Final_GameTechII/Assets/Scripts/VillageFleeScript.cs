﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class VillageFleeScript : MonoBehaviour
{

    Transform player;
    NavMeshAgent vAgent;
    float nextTurnTime;
    Transform startTransform;
    float range;

    public float multiplyBy;
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.Find("Player").GetComponent<Transform>();
        vAgent = this.GetComponent<NavMeshAgent>();
        multiplyBy = 10f;
        range = 5f;
        if(Vector3.Distance(player.position, transform.position) <= range)
        {
            RunFrom();
        }
       
    }

    // Update is called once per frame
    void Update()
    {
        if(Vector3.Distance(player.position, transform.position) <= range)
        {
            RunFrom();
        }
    }

    public void RunFrom()
    {
      
        startTransform = transform;

        transform.rotation = Quaternion.LookRotation(transform.position - player.position);

        Vector3 runTo = transform.position + transform.forward * multiplyBy;

        NavMeshHit hit;

        NavMesh.SamplePosition(runTo, out hit, 5, 1 << NavMesh.GetAreaFromName("Walkable"));

        transform.position = startTransform.position;
        transform.rotation = startTransform.rotation;

        vAgent.SetDestination(hit.position);
    }
}
