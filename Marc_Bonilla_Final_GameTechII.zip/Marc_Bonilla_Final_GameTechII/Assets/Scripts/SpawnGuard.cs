﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnGuard : MonoBehaviour
{

    public GameObject guard;
    public Vector3 spawn;
    // Start is called before the first frame update
    void Start()
    {
        spawn = transform.position;
        Delay();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        
    }

    void GuardSpawn()
    {
        
        Instantiate(guard, spawn, transform.rotation);
    }

    void Delay()
    {
        InvokeRepeating("GuardSpawn", 20f, 15f);
    }
}
