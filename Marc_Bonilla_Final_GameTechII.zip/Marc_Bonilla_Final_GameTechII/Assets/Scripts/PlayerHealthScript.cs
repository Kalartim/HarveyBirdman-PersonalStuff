﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class PlayerHealthScript : MonoBehaviour
{
    GameObject player;
    public int playerHealth = 100;
    public Text healthPoints;
    public Collider other;
    int damage = 25;
    AudioSource sound;
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.Find("Player");
        healthPoints = GameObject.Find("Health_Number").GetComponent<Text>();
        sound = GameObject.Find("Hurt_Sound").GetComponent<AudioSource>();
        //healthPoints.text = playerHealth.ToString();
    }

    // Update is called once per frame
    void Update()
    {
        OnAllLost();
    }

    void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag == "Guard")
        {
            sound.Play();
            playerHealth -= damage;
            healthPoints.text = playerHealth.ToString();
            Destroy(other.gameObject);
        }
       
    }

    void OnAllLost()
    {
        if(playerHealth == 0)
        {
            SceneManager.LoadScene("End_Scene");
        }
       
    }
}
