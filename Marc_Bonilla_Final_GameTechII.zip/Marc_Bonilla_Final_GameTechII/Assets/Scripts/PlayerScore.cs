﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class PlayerScore : MonoBehaviour
{

    public int villagers;
    public int captured = 0;
    

    public Text vText;
    public Text cText;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        UpdateScore();
        OnAllCaptured();
    }

    void UpdateScore()
    {
        vText.text = villagers.ToString();
        cText.text = captured.ToString();
    }

    void OnAllCaptured()
    {
        if(villagers == 0)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
    }
}

