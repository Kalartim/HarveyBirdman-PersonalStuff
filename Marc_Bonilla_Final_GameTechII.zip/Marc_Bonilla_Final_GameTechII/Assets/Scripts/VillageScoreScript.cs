﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class VillageScoreScript : MonoBehaviour
{

    public PlayerScore playerScore;
    public Collider other;
    AudioSource sound;
    // Start is called before the first frame update
    void Start()
    {
        sound = GameObject.Find("Capture_Sound").GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.name == "Player")
        {
            sound.Play();
            playerScore.villagers--;
            playerScore.captured++;
            Destroy(gameObject);
        }
        

    }
}
    
