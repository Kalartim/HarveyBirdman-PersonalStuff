﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class PlayerMovementScript : MonoBehaviour
{

   NavMeshAgent agent;
   public GameObject player;
   Rigidbody rb;
   


   // Start is called before the first frame update
   void Start()
   {
      agent = player.GetComponent<NavMeshAgent>();
      rb = player.GetComponent<Rigidbody>();
   }

   // Update is called once per frame
   void Update()
   {
       if (Input.GetMouseButtonDown(1))
      {
         Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
         RaycastHit hit;

         if (Physics.Raycast(ray, out hit, 100))
         {
              agent.SetDestination(hit.point);
         }
      }
   }
}
    

