﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class GuardFollowScript : MonoBehaviour
{
  
   public GameObject player;
   public Transform playerLocation;
   NavMeshAgent agent;
   float speed = 3f;
    // Start is called before the first frame update
    void Awake()
    {
      player = GameObject.Find("Player");
      agent = GetComponent<NavMeshAgent>();
      agent.enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        Invoke("Follow", 3f);
      //transform.position = Vector3.MoveTowards(transform.position, playerLocation.position, step);
    
    }

    void Follow()
    {
        agent.enabled = true;
        float step = speed * Time.deltaTime;
        agent.destination = player.transform.position;
        if(player.tag == "Player")
        {
            agent.destination = player.transform.position;
            
        }
        
    }
}
