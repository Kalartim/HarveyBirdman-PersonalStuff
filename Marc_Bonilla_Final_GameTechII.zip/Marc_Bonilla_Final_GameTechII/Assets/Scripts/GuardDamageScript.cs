﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GuardDamageScript : MonoBehaviour
{

    public PlayerHealthScript phs;
    public int damage = 25;
    public Collider other;
    public Collider col;
  
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter(Collider other)
    {
        /*if(other.gameObject.name == "Player")
        {
            phs.playerHealth -= damage;
            phs.healthPoints.text = phs.playerHealth.ToString();
            Destroy(gameObject);
        }*/
        

       if (other.gameObject.tag == "Trap")
        {
            Destroy(other.gameObject);
            Destroy(gameObject);
        }
    }
    
}
