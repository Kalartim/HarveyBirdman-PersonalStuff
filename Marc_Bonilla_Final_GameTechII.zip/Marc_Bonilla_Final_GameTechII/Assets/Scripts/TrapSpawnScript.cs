﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrapSpawnScript : MonoBehaviour
{
    public GameObject prefab;
    Vector3 spawnRange;
    float timer;
    // Start is called before the first frame update
    void Awake()
    {
        timer = Time.time + 15;
        spawnRange = new Vector3(Random.Range(-23.5f, 23.5f), 0.95f, Random.Range(-23.5f, 23.5f));
    }

    // Update is called once per frame
    void Update()
    {
        InvokeRepeating("SpawnTheThings", 8f, 8f);
    }

    void SpawnTheThings()
    {
        spawnRange = new Vector3(Random.Range(-23.5f, 23.5f), 0.95f, Random.Range(-23.5f, 23.5f));
        if (timer < Time.time)
        {
            Instantiate(prefab, spawnRange, Quaternion.identity);
            timer = Time.time + 15;
        }   
       
    }
}
