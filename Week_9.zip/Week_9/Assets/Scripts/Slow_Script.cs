﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Slow_Script : MonoBehaviour
{

    public DriveScript driveScript;
    public Collider col;

    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(Seconds());
    }

    // Update is called once per frame
    void Update()
    {
        
    }

     void OnTriggerEnter(Collider other)
    {
        driveScript.speed = 25f;
        Seconds();
        Destroy(gameObject);
    }

    IEnumerator Seconds()
    {
        yield return new WaitForSeconds(2);
    }
}
