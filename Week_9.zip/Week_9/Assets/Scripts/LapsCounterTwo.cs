﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LapsCounterTwo : MonoBehaviour
{
    public int lapCounter = 1;
    //int playerLabel = 2;
    //Text winText;
    GoalScript gScript;
    // Start is called before the first frame update
    void Start()
    {
        gScript = GameObject.Find("Goal_Trigger").GetComponent<GoalScript>();
       // winText = GameObject.Find("Player_Win_Text").GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        //winText = GameObject.Find("Player_Win_Text").GetComponent<Text>();
        if (lapCounter == gScript.lapsTwo)
        {
            //winText.text = playerLabel.ToString();
        }
    }
}
