﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpeedScript : MonoBehaviour
{

   public DriveScript driveScript;
    public DriveTwo driveTwo;
   public Collider col;

    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(Seconds());
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.name == "Car" || other.gameObject.name == "Car_Two")
        {
            driveScript.speed = 75f;
            Seconds();
            Destroy(gameObject);
        }
        
    }

    IEnumerator Seconds ()
    {
       yield return new WaitForSeconds(2);
    }
}
