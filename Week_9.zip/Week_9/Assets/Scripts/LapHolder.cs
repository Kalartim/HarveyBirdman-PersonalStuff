﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class LapHolder : MonoBehaviour
{
    public LapsCounterOne lapOne;
    public LapsCounterTwo lapTwo;
    public GoalScript goal;

    public int realOne;
    public int realTwo;

    public int playerOneLabel;
    public int playerTwoLabel;
    // Start is called before the first frame update

    void Awake()
    {
        DontDestroyOnLoad(this.gameObject);
    }
    void Start()
    {
        lapOne = GameObject.Find("Car").GetComponent<LapsCounterOne>();
        lapTwo = GameObject.Find("Car_2").GetComponent<LapsCounterTwo>();
        goal = GameObject.Find("Goal_Trigger").GetComponent<GoalScript>();

        playerOneLabel = 1;
        playerTwoLabel = 2;
    }

    // Update is called once per frame
    void Update()
    {
        realOne = lapOne.lapCounter;
        realTwo = lapTwo.lapCounter;

       if (realOne == 1 && realTwo !=1)
        {
            SceneManager.LoadScene("End_State");
        }

       if (realTwo == 1 && realOne !=1)
        {
            SceneManager.LoadScene("End_State");
        }
    }


}
