﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{

    float speed = 5f;
    Rigidbody rb;
    PlayerInput playerInput;
    bool shouldJump;
    float jumpForce = 10f;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        playerInput = GetComponent<PlayerInput>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (playerInput.controllerAssigned) Move();
    }

   void Move()
    {
        Vector3 movement = new Vector3(playerInput.horizontal, 0f, playerInput.vertical);
        rb.AddForce(movement * speed);
        if (shouldJump) Jump();
    }

    void CheckJump()
    {
        if(playerInput.IsButtonDown("A"))
        {
            shouldJump = true;
        }
    }

    void Jump()
    {
        shouldJump = false;
        rb.AddForce(Vector3.up * jumpForce);
    }
}
