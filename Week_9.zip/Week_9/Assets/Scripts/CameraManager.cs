﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraManager : MonoBehaviour
{

    public GameObject[] cameras;
    public PlayerData playerData;
    
    [System.Serializable]
    public struct PlayerCamera
    {
        public string name;
        public string key;
        public GameObject camera;
    }

    public PlayerCamera[] playerCameras;

    // Start is called before the first frame update
    void Start()
    {
        TurnOffAllCameras();
    }

    // Update is called once per frame
    void Update()
    {
        CheckInput();
    }

    void TurnOffAllCameras()
    {
        foreach(PlayerCamera pc in playerCameras)
        {
            pc.camera.SetActive(false);
        }
    }

    void CheckInput()
    {
        if(Input.anyKeyDown)
        {
            SetCamera(Input.inputString);
        }
    }

    void SetCamera(string key)
    {
        foreach(PlayerCamera pc in playerCameras)
        {
            if(pc.key == key)
            {
                TurnOffAllCameras();
                pc.camera.SetActive(true);
                break;
            }
        }
    }
}
