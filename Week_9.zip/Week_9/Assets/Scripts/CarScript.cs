﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class CarScript : MonoBehaviour
{

    public enum CarColor { red, blue, green, yellow};


    public CarColor carColor;

    // Start is called before the first frame update
    void Start()
    {
        InitColor();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void InitColor()
    {
        Material mat = new Material(Shader.Find("Standard"));
        switch(carColor)
        {
            case CarColor.red:
                mat.color = Color.red;
                break;
            case CarColor.blue:
                mat.color = Color.blue;
                break;
            case CarColor.green:
                mat.color = Color.green;
                break;
            case CarColor.yellow:
                mat.color = Color.yellow;
                break;

        }
        GetComponent<Renderer>().material = mat;
    }
}
