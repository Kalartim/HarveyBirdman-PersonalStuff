﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerManager : MonoBehaviour
{

    public string operatingSystem;
    public string opSys;

    public GameObject[] players;
    public bool allControllersAssigned;

    public List<int> assignedControllers = new List<int>();

    public static ControllerManager instance;

    // Start is called before the first frame update
    void Start()
    {
        instance = this;
        CheckOS();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void CheckOS()
    {
        operatingSystem = SystemInfo.operatingSystem;
        if (operatingSystem.Contains("Mac"))
        {
            opSys = "Mac";
        }
        else if (operatingSystem.Contains("Windows"))
        {
            opSys = "Win";
        }
        else
        {
            opSys = "Win";
        }
    }

    void CheckInput()
    {
        //loop through players
        for (int i = 0; i < players.Length; i++)
        {
            //if that number is already assigned, continue
            if (assignedControllers.Contains(i))
            {
                continue;
            }
        }
        for (int i = 1; i <= players.Length; i++)
        {
            if (Input.GetButton("Player_"+ i +"_A") || Input.GetButton("Player_" + i + "_A_Mac_"))
            {
                //Debug.Log("A button pressed.");
                AddPlayerController(i);
                break;
            }
        }
    }

    void AddPlayerController(int controller)
    {
      
        //add controller number to the list
        assignedControllers.Add(controller);
        for(int i = 0; i < players.Length; i++)
        {

            PlayerInput playerInput = players[i].GetComponent<PlayerInput>();
            if(playerInput.controllerAssigned == false)
            {
                playerInput.SetControllerNumber(controller);
                break;
            }

        }
        if(assignedControllers.Count == players.Length)
        {
            allControllersAssigned = true;
        }
    }
}
