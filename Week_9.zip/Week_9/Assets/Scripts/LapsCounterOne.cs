﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LapsCounterOne : MonoBehaviour
{

    public int lapCounter = 1;
    //int playerLabel = 1;
    //Text winText;
    GoalScript goalScript;
    
    // Start is called before the first frame update
    void Start()
    {
        goalScript = GameObject.Find("Goal_Trigger").GetComponent<GoalScript>();
        //winText = GameObject.Find("Player_Win_Text").GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
       // winText = GameObject.Find("Player_Win_Text").GetComponent<Text>();
        if (lapCounter == goalScript.laps)
        {
           // winText.text = playerLabel.ToString();
        }
    }
}
