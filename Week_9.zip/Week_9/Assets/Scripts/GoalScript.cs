﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class GoalScript : MonoBehaviour
{

    public GameObject car;
    public Text lapText;
    Collider col;
    public int laps = 0;
    public GameObject completeState;
    public int lapsTwo = 0;
    public Text lapTextTwo;
     void Awake()
    {
        completeState = GameObject.Find("Race_Completed");
        //completeState.SetActive(false);
    }
    // Start is called before the first frame update
    void Start()
    {
        col = car.GetComponent<Collider>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.name == "Car")
        {
            laps++;
            lapText.text = laps.ToString();
        }
        
        if (col.gameObject.name == "Car_2")
        {
            lapsTwo++;
            lapTextTwo.text = lapsTwo.ToString();
        }

        if (laps == 1 || lapsTwo == 1)
        {
            SceneManager.LoadScene("End_Game");
        }
    }
}
