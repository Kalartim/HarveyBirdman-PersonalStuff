﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInput : MonoBehaviour
{

    string horizontalAxis;
    string verticalAxis;
    string aButton;

    public float horizontal;
    public float vertical;

    public int controllerNumber;
    public bool controllerAssigned;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void SetControllerNumber(int controller)
    {
        string osString = "";
        if (ControllerManager.instance.opSys == "Mac")
        {
            osString = "_Mac";
        }

        horizontalAxis = "Player_" + controller + "_Horizontal";
        verticalAxis = "Player_" + controller + "_Vertical";
        aButton = "Player_" + controller + "_A" + osString;
        controllerNumber = controller;
        controllerAssigned = true;
    }

    public bool IsButtonDown(string button)
    {
        switch(button)
        {
            case "A":
                return Input.GetButtonDown(aButton);
        }

        return false;
    }
    // Update is called once per frame
    void Update()
    {
        if(controllerAssigned)
        {
            horizontal = Input.GetAxis(horizontalAxis);
            vertical = Input.GetAxis(verticalAxis);
        }
    }
}
