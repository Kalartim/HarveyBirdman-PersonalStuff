﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DriveTwo : MonoBehaviour
{
    public WheelCollider frontRight;
    public WheelCollider frontLeft;
    public WheelCollider backRight;
    public WheelCollider backLeft;

    public float turning = 12f;
    public float speed = 50f;
    // Start is called before the first frame update
    void Start()
    {
        frontRight.ConfigureVehicleSubsteps(5f, 12, 15);
        frontLeft.ConfigureVehicleSubsteps(5f, 12, 15);
        backRight.ConfigureVehicleSubsteps(5f, 12, 15);
        backLeft.ConfigureVehicleSubsteps(5f, 12, 15);
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        Drive();
    }

    void Drive()
    {
        if(Input.GetKeyDown(KeyCode.LeftArrow))
        {
            frontLeft.steerAngle = Input.GetAxis("Horizontal") * turning;
            backLeft.motorTorque = Input.GetAxis("Vertical") * speed;
        }
       
        if(Input.GetKeyDown(KeyCode.RightArrow))
        {
            frontRight.steerAngle = Input.GetAxis("Horizontal") * turning;
            backRight.motorTorque = Input.GetAxis("Vertical") * speed;
        }  
        
        if(Input.GetKeyDown(KeyCode.UpArrow))
        {

        }
     
    }
}

