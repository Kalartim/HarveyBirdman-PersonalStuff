﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PlayerData 
{
    public int speed = 10;
    public string name = "Marc";
    public float health = 100f;

}
