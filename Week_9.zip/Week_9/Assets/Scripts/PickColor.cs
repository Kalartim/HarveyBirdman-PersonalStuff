﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PickColor : MonoBehaviour
{

    public Button redButton;
    public Button blueButton;
    public Button yellowButton;
    public Button greenButton;

    // Start is called before the first frame update
    void Start()
    {
        redButton.Select();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
