﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
public class SpawnCube : MonoBehaviour
{

    public GameObject cubePrefab;


    [ContextMenu("Spawn Cube")]

    void CubeSpawn()
    {
        Instantiate(cubePrefab);
    }

    [ContextMenu("Spawn Cube Prefab")]
    void SpawnCubePrefab()
    {
        PrefabUtility.InstantiatePrefab(cubePrefab);
    }


}
