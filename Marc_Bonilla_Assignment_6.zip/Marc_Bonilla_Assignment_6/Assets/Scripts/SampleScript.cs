﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SampleScript : MonoBehaviour
{

    public int myInt;
    public string myString;
    public Transform myTransform;

    
    void Start()
    {
        
    }

    
    void Update()
    {
        
    }
}
