﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class BuildSpheres : MonoBehaviour
{
    public GameObject spherePrefab;
    public List<GameObject> sphereList = new List<GameObject>();

    public void BuildSphere()
    {
        GameObject sphere = PrefabUtility.InstantiatePrefab(spherePrefab) as GameObject;


        sphere.name = "Sphere_" + sphereList.Count;
        //add sphere to the list
        sphereList.Add(sphere);
    }

    public void DeleteAllSpheres()
    {
        while(sphereList.Count > 0)
        {
            DestroyImmediate(sphereList[0]);
            sphereList.RemoveAt(0);
        }
    }
}
