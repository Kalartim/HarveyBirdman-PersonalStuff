﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelScript : MonoBehaviour
{
    public int experience;
    public int Experience
    {
        get
        {
            return experience;
        }

        set
        {
            if(value < 0)
            {
                experience = 0;
            }
            else
            {
                experience = value;
            }
        }
    }

    public int Level
    {
        get
        {
            return Experience / 333;
        }
    }
    public int health;
    
    int Health
    {

        get
        {
            return health;
        }
        
        set
        {
            if (value > 10)
            {
                health = 10;
            }
            else if (value < 0)
            {
                health = 0;
            }
            else
            {
                health = value;
            }
            Doot();
        }

    }

    private void Start()
    {
        Health = 20;
    }

    void Doot()
    {
        Debug.Log("Doot");
    }

}
