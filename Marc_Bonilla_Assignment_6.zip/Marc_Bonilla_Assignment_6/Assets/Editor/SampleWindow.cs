﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class SampleWindow : EditorWindow
{

    string myString;
    bool myBool;
    float myFloat = 3.14f;
    bool groupEnabled = false;

    [MenuItem("Window/Sample Window")]
    public static void ShowWindow()
    {
        EditorWindow.GetWindow(typeof(SampleWindow));
    }

    void OnGUI()
    {
        GUILayout.Label("Sample Window", EditorStyles.boldLabel);
        myString = EditorGUILayout.TextField("myString", myString);

        groupEnabled = EditorGUILayout.BeginToggleGroup("Optional Settings", groupEnabled);
        myBool = EditorGUILayout.Toggle("myBool", myBool);
        myFloat = EditorGUILayout.Slider("myFloat", myFloat, -10f, 10f);


    }
}
