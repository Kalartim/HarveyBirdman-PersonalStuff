﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
public class DoSomethingFromMenu 
{
    [MenuItem("Tools/Do Something")]
   static void DoSomething()
    {
        Debug.Log("Yeet");
    }

    [MenuItem("Tools/Levels/Do Something Else _g")]
    static void DoSomethingElse()
    {
        Debug.Log("Yoink");
    }
}
