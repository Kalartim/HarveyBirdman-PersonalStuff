﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

//[CustomEditor(typeof(EnemyScript))]
public class EnemyEditor : Editor
{

    public override void OnInspectorGUI()
    {
        EnemyScript enemy = (EnemyScript)target;
        enemy.damage = EditorGUILayout.IntSlider("damage", enemy.damage, 0, 100);
        enemy.armor = EditorGUILayout.IntSlider("armor", enemy.armor, 0, 100);


        bool allowSceneObject = !EditorUtility.IsPersistent(target);
        enemy.special = (GameObject)EditorGUILayout.ObjectField("weapon", enemy.special, typeof(GameObject), allowSceneObject);
    }
}
