﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(BuildSpheres))]
public class BuildSpheresEditor : Editor
{

    public override void OnInspectorGUI()
    {
        BuildSpheres buildSpheres = (BuildSpheres)target;
        #region Horizontal Buttons
        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("Build Sphere"))
        {
            buildSpheres.BuildSphere();
        }
        if (GUILayout.Button("Delete All Spheres"))
        {
            buildSpheres.DeleteAllSpheres();
        }
        #endregion EditorGUILayout.EndHorizontal();
        DrawDefaultInspector();

    }

}
