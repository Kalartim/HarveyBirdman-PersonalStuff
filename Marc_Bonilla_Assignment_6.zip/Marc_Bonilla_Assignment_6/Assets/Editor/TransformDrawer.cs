﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
[CustomEditor(typeof(Transform))]
public class TransformDrawer : Editor
{
    public override void OnInspectorGUI()
    {
        Transform t = (Transform)target;

        Vector3 globalPosition = EditorGUILayout.Vector3Field("Global Position", t.position);
        Vector3 localPosition = EditorGUILayout.Vector3Field("Local Position", t.localPosition);
    }
}
