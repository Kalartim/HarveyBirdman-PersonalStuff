﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(EnemyScript))]
[CanEditMultipleObjects]
public class EnemyScriptMultEditor : Editor
{
    SerializedProperty damageProp;
    SerializedProperty armorProp;
    SerializedProperty specialProp;

    void OnEnable()
    {
        damageProp = serializedObject.FindProperty("damage");
        armorProp = serializedObject.FindProperty("armor");
        specialProp = serializedObject.FindProperty("special");
    }

    public override void OnInspectorGUI()
    {
        serializedObject.Update();
        EditorGUILayout.IntSlider(damageProp, 0, 100, new GUIContent("damage"));
        if(!damageProp.hasMultipleDifferentValues)
        ProgressBar(damageProp.intValue / 100f, "damage");


        EditorGUILayout.IntSlider(armorProp, 0, 100, new GUIContent("armor"));
        if(!armorProp.hasMultipleDifferentValues)
        ProgressBar(armorProp.intValue / 100f, "armor");

        EditorGUILayout.PropertyField(specialProp, new GUIContent("weapon"));
        serializedObject.ApplyModifiedProperties();
    }
    // Update is called once per frame
    void Update()
    {
        
    }

    void ProgressBar(float value, string label)
    {
        Rect rect = GUILayoutUtility.GetRect(18, 18, "Textfield");
        EditorGUI.ProgressBar(rect, value, label);
    }
}
