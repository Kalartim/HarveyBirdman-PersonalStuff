﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;


[CustomEditor(typeof(LevelScript))]
public class LevelScriptEditor : Editor
{
    public override void OnInspectorGUI()
    {
        LevelScript levelScript = (LevelScript)target;

        levelScript.Experience = EditorGUILayout.IntField("Experience", levelScript.Experience);
        EditorGUILayout.LabelField("Level", levelScript.Level.ToString());
        
    }
    
}
