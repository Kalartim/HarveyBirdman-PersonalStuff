﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class ChangeNameWindow : EditorWindow
{

    public GameObject[] gameObjects;
    int numSelected = 0;
    string startNameString;
    int startIndex = 0;

   [MenuItem("Tools/Change Names")]
    public static void ShowWindow()
    {
        EditorWindow.GetWindow(typeof(ChangeNameWindow));
    }

    private void OnGUI()
    {
        EditorGUILayout.LabelField("Number Selected: ", numSelected.ToString());
        startNameString = EditorGUILayout.TextField("Start Name", startNameString);
        startIndex = EditorGUILayout.IntField("Start Index", startIndex);
        if(GUILayout.Button("Change Name"))
        {
            ChangeNames();
        }
        EditorHelper.DrawLine(Color.red);
    }

 
    private void Update()
    {
        gameObjects = Selection.gameObjects;
        if (gameObjects.Length != numSelected)
        {
            numSelected = gameObjects.Length;
            Repaint();
        }
        
    }

    void ChangeNames()
    {
        for (int i = 0; i < gameObjects.Length; i++)
        {
            int index = startIndex + i;
            gameObjects[i].name = startNameString + "_" + index;
        }
    }
}
