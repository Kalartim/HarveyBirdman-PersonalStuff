﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;


[CustomEditor(typeof(SampleScript))]
public class SampleScriptEditor : Editor
{

    public override void OnInspectorGUI()
    {
        //base.OnInspectorGUI();
        EditorGUILayout.HelpBox("Hello there!", MessageType.Info);
    }


}
